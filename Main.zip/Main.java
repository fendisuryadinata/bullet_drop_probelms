import java.util.Scanner;

public class Main {
	Scanner scan = new Scanner(System.in);
	
	public Main() {
		double latitude;
		double longitude;
		double degree;
		
		final double bulletSpeed = 700;
		final double humanHeight = 1.6;
		final double gravity = 9.81;
		
		latitude = scan.nextDouble();
		longitude = scan.nextDouble();
		degree = scan.nextDouble();
		scan.nextLine();
		
		double distance = bulletSpeed * Math.sqrt(2*humanHeight/gravity);
		
		
		System.out.println(latitude+distance*Math.cos(degree));
		System.out.println(longitude+distance*Math.sin(degree));
//		System.out.println(Math.sqrt(Math.pow(latitude+distance*Math.cos(degree),2)+Math.pow(longitude+distance*Math.sin(degree),2)));
//		System.out.println(latitude+distance*Math.cos(0));
		
//		System.out.println(latitude);
//		System.out.println(longitude);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
